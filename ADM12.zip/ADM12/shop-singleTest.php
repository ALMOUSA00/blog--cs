<?php

include 'include/header.php';

?>


<!--Page Title-->
<section class="page-title" style="background-image:url('images/bk21.jpg')">
    <?php
    if (isset($_GET['post'])) {
        $pID = $_GET['post'];
        $sql  = "SELECT * FROM post  WHERE  $pID = post.p_id";
        $posts = mysqli_query($conn, $sql);
        while ($p = mysqli_fetch_assoc($posts)) {
            echo "
    <div class='auto-container'>
    <h1>{$p['post_name']}</h1>
    <ul class='page-breadcrumb'>
        <li><a href='index.php'>home</a></li>
        <li><a href='shop.php'>Products</a></li>
        <li>{$p['post_name']}</li>
    </ul>
     </div>
    ";
        }
    } ?>



</section>
<!--Sidebar Page Container-->
<div class="sidebar-page-container">
    <div class="auto-container">
        <div class="row clearfix">

            <!--Content Side-->
            <div class="content-side col-lg-9 col-md-12 col-sm-12">
                <div class="shop-single">

                    <!-- Product Detail -->
                    <div class="product-details">
                        <!--Basic Details-->
                        <div class="basic-details">
                            <div class="row clearfix">

                                <?php
                                if (isset($_GET['post'])) {
                                    $pID = $_GET['post'];
                                    $sql  = "SELECT * FROM post  WHERE  $pID = post.p_id";
                                    $posts = mysqli_query($conn, $sql);
                                    while ($p = mysqli_fetch_assoc($posts)) {
                                        $IdPos = $p['p_id'];
                                        $description = $p['post_des']; ?>

                                        <div class='image-column col-md-6 col-sm-12'>
                                            <figure class='image'>
                                                <?php echo  "<img src='images/catogary/{$p['post_img']}' alt=''  style='height: 17rem'>"; ?>

                                            </figure>
                                        </div>
                                        <div class='info-column col-md-6 col-sm-12'>
                                            <div>
                                                <div class='details-header'>
                                                    <?php echo "<h4>{$p['post_name']}</h4>" ?>
                                                    <div class='rating'>
                                                        <span class='fa fa-star'></span>
                                                        <span class='fa fa-star'></span>
                                                        <span class='fa fa-star'></span>
                                                        <span class='fa fa-star'></span>
                                                        <span class='fa fa-star'></span>
                                                    </div>
                                                    <a class='reviews' href='#'>(2 Customer Reviews)</a>
                                                    <br>
                                                    
                                                    <br>
                                                    <div class='text'>Accumsan lectus, consectetuer
                                                        et sagittis et commodo, massa et, sed facilisi mi, sit diam.
                                                        Ultrices facilisi convallis nullam duis. Aliquam lacinia orci
                                                        convallis erat ac, vitae neque in class.
                                                    </div>
                                                </div>

                                                <form action="shopping-cart.php" method='get'>
                                                    <div class='other-options clearfix'>
                                                        <div class='item-quantity'>Quantity
                                                            <input name="quantity" min=1 type="number" id='quantity' class="qty" value="<?php echo $p_qty; ?>">
                                                            <input name="description" type="hidden" value="<?php echo $p['post_des']; ?>">
                                                        </div>
                                                        <button type="submit" name="post" class="theme-btn add-to-cart" value="<?php echo $p['p_id']; ?>">Add to cart</button>
                                                    </div>

                                                </form>
                                            <?php
                                        }; ?>
                                            </div>
                                        </div>
                                    <?php
                                } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--End Page Title-->

<?php include 'include/footer.php' ?>