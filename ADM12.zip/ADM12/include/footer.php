<div class="wrapper row4 bgded overlay" style="background-image:url('images/footer.png');">
      <footer id="footer" class="hoc clear"> 
        <!-- ################################################################################################ -->
        <div class="row ">
          <div class="col">
          <h6 class="heading" ><a style="text-decoration:none; color:#fe7831;" href="https://www.orange.jo/en/Pages/default.aspx">orange jordan</a></h6>
          <nav>
            <ul class="nospace">
              <li><a href="index.php"><i class="fa fa-lg fa-home"></i></a>
              </li><br/><br/>
              <li>
                <a href="https://www.orange.jo/EN/Pages/about-orange.aspx">About Orange</a><br/><br/>
              </li>
              <li>
                <a href="#">Privacy</a><br/><br/>
              </li>
              <li>
                <a href="https://orange.elevatus.io/">Careers</a><br/><br/>
              </li>
              <li>
                <a href="#">Disclaimer</a><br/><br/>
              </li>
              <li>
                <a href="https://www.orange.jo/en/pages/coverage.aspx">Map</a><br/><br/>
              </li>
              <li>
                <a href="https://store.orange.jo/">Locate store</a><br/><br/>
              </li>
            </ul>
          </nav>
          <p>Follow US :</p>
          <ul class="faico clear">
            <li><a class="faicon-facebook" href="https://www.facebook.com/OrangeJordan/"><i class="fa fa-facebook"></i></a></li>
            <li><a class="faicon-twitter" href="https://twitter.com/orangejo?lang=en"><i class="fa fa-twitter"></i></a></li>
            <li><a class="faicon-instagram" href="https://www.instagram.com/orangejo/?hl=en"><i class="fa fa-instagram"></i></a></li>
            <li><a class="faicon-linkedin" href="https://www.linkedin.com/company/orange-jordan"><i class="fa fa-linkedin"></i></a></li>
            <li><a class="faicon-google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
            <li><a class="faicon-youtube" href="https://www.youtube.com/orangejordan"><i class="fa fa-youtube"></i></a></li>
          </ul>
        </div>
        <div class="col">
          <h6 class="heading" > <a style="text-decoration:none; color:#fe7831;" href="https://www.orange.jo/en/pages/contact-us.aspx">CONTACT US</a></h6>
          <ul class="nospace linklist contact">
            <li><i class="fa fa-map-marker"></i>
              <address>
              Abdali,boulevard,gate (2)
              </address>
            </li>
            <li><i class="fa fa-phone"></i>(06) 67493</li>
            <li><i class="fa fa-mobile"></i> +00 (123) 456 7890</li>
            <li><i class="fa fa-envelope-o"></i> orange123@orange.com</li>
          </ul>
        </div>
        <br><br>
        <div class="col">
          <h6 class="heading" style="color:#fe7831;">most viewed articles</h6>
          <ul class="nospace linklist">
            <li>
              <article>
                <h2 class="nospace font-x1"><a href="#">test 11</a></h2>
                <time class="font-xs block btmspace-10" datetime="2021-04-06">Friday, 6<sup>th</sup> April 2021</time>
                <p class="nospace">Elit praesent laoreet rutrum placerat suspendisse suscipit ex ut nibh <a href="#">[&hellip;]</a></p>
              </article>
            </li>
            <li>
              <article>
                <h2 class="nospace font-x1"><a href="#">Test 32</a></h2>
                <time class="font-xs block btmspace-10" datetime="2021-08-05">Thursday, 5<sup>th</sup> August 2021</time>
                <p class="nospace">Tortor laoreet praesent nec molestie justo ut non consequat tortor iaculis <a href="#">[&hellip;]</a></p>
              </article>
            </li>
          </ul>
        </div>
        </div>
</div>
      </footer>
    </div>
</body>
</html>