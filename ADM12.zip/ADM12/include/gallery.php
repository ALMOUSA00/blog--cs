<?php
require 'connection.php';
?>



<!DOCTYPE html>

<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="plugins/revolution/css/settings.css" rel="stylesheet" type="text/css">
<link href="plugins/revolution/css/layers.css" rel="stylesheet" type="text/css">
<link href="plugins/revolution/css/navigation.css" rel="stylesheet" type="text/css">
<link href="layout/style/layout.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <title>Orange</title>
</head>
<body id="top">

<div class="wrapper row2">
  <div id="breadcrumb" class=""> 
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="index.php">category</a></li>
      <li><a href="#"><div class="sec-title text-center">
                          <?php if (isset($_GET['id'])) {
                    $sql  = "select cat_name , cat_des , cat_id  from category where cat_id= {$_GET['id']}";
                    $cat = mysqli_fetch_assoc(mysqli_query($conn, $sql));
                    if ($_GET['id'] == $cat['cat_id']) {
                        echo ' <h2>  ' . $cat['cat_name'] . $cat['cat_des'] . ' </h2>';
                    }
                } else {
                    echo ' <h2> Stores </h2>';
                }
                ?>
             <!-- <h2>Story </h2> -->
         </div></a></li>
    </ul>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="sidebar-page-container">
    <div class="auto-container">
        <div class="row clearfix">

            <!--Content Side-->
            <div class="content-side col-lg-9 col-md-12 col-sm-12">
              <div class="p-5">
                <div class="row clearfix ">
                    <?php
                if (isset($_GET['id'])) {
                    $sql  = "select cat_id from category where cat_id= {$_GET['id']}";
                    $cat = mysqli_fetch_assoc(mysqli_query($conn, $sql));
                    $catId = $cat['cat_id'];
                    if ($_GET['id'] == $catId) {
                        $query  = "select * from post  where cat_id= $catId";
                        $result3 = mysqli_query($conn, $query);
                        while ($row = mysqli_fetch_assoc($result3)) {
                          echo '<div class="recipe-block-two col-lg-3 col-md-6 col-sm-12">
                <div class="image-box"> <figure class="image">
                <img src="ADMIN/images/' . $row['post_img'] . '" alt="" style="height:15rem; width:15rem; "></figure>';
                echo ' <div class="caption-box"> ';
                echo ' <h3 class="recipe-title text-capitalize">
                      ' .$row['post_name'] .'  </h3>';
                echo ' <h4 class="recipe-title ">
                <p  class="text-dark text-truncate text-decoration-none text-capitalize " ' .$row['p_id'] . '&type=' .$row['post_des'] . ' </p>
                </h4>';
                echo ' <h4 class="recipe-title text-capitalize" >
                        <a href="post.php?id=' . $row['p_id'] . '" "  >More...</a>
                        </h4>';
                          echo ' </div></div></div> ';
                        }
                    }
                } 
                ?>


                        
               </div>
              </div>  
            </div>

            <!--Sidebar Side-->
            <div class="sidebar-side sticky-container col-lg-3 col-md-12 col-sm-12">
                <aside class="sidebar theiaStickySidebar">
                    <div class="sticky-sidebar">
                        <!-- Tags Widget -->
                        <div class="section topics">
                          <h2 class="section-title">Category</h2>
                          <ul>
                           <?php
                              $query  = "select * from category";
                               $result = mysqli_query($conn, $query);
                               while ($row = mysqli_fetch_assoc($result)) {
                              echo '  <li><a href="catogery.php?id=' . $row['cat_id'] . '&type=' . $row['cat_name'] . '" >' . $row['cat_name'] . '</a></li>';
                              }
                           ?>
                          </ul>
                       </div>
                     </div>
                 </aside>
             </div>
        </div>
    </div>
</div>

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>