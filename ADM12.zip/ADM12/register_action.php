<?php
require_once './public/connection.php';

date_default_timezone_set('Asia/Ho_Chi_Minh');

$name = $_POST['name'];
$email = $_POST['email'];
$dep=$_POST['dep'];
$password = $_POST['password'];
$password2 = $_POST['password2'];

$data = $_POST;

if (empty($data['name']) ||
    empty($data['password']) ||
    empty($data['email']) ||
    empty($data['dep']) ||
    empty($data['password2'])) {
 
    
  die('Please fill all required fields!');
}



if ($password2 != $password) {
    setcookie('msg', 'Retype the password incorrectly!', time() + 3);
    header('Location: register.php');
} else {
    $status = 1;

  
    // $password = password_hash($password, PASSWORD_BCRYPT);
    $password = sha1($_POST['password']);
    $con = mysqli_connect("localhost","root","","database");
    if (isset($_POST['register'])) {
    $email = $_POST['u_email'];
    $sql = "SELECT * FROM user WHERE u_email='$email'";
    $res = mysqli_query($db, $sql);
 
    if(mysqli_num_rows($res) > 0){
    $email_error = "Sorry... email already taken";  
    }else{
    $query = mysqli_query($con, "INSERT INTO `user`(`u_email`) VALUES('$email')");
    echo 'Saved!';
  }
}
    $query = "INSERT INTO user(u_email, user_pass, username , user_dep ,  status) VALUES ('" . $email . "', '" . $password . "', '" . $name . "','" . $dep . "' ,'" . $status . "')";
    // die($query);
   
    $result = $connection->query($query);
    // echo $result; die;

      if ($result) {
        setcookie('msg', 'Register successful!', time() + 3);
        header('Location: s.php');
    } else {
        setcookie('msg', 'Sorry... email already taken!!!!', time() + 3);
        header('Location: register.php');
    }
}