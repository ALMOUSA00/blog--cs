<?php
require('include/connection.php');

$name     = "";
$email    = "";
$password = "";
$user_department ="";
$update  = false;

if (isset($_GET['action']) && $_GET['action'] == 'edit') {

    // fetch old data 
    $query  = "SELECT * FROM user WHERE user_id = {$_GET['id']}";
    $result = mysqli_query($conn, $query);
    $row    = mysqli_fetch_assoc($result);
    $name   = $row['username'];
    $email  = $row['u_email'];
    $password = $row['user_pass'];
    $user_department = $row['user_dep'];
    $update = true;
    // print_r($row);


    if (isset($_POST['update'])) {

        // fetch data from form 
        $name     = $_POST['name'];
        $email    = $_POST['email'];
        $password = $_POST['password'];
        $user_department = $_POST['user_department'];

     

        $query = "UPDATE user SET username = '$name',
	                           u_email = '$email',
	                           user_pass = '$password',
                               user_dep ='$user_department'
	                           WHERE user_id = {$_GET['id']}";
        mysqli_query($conn, $query);

        $update = false;
        header("location:user.php");
    }
}

if (isset($_POST['submit'])) {
    // fetch data from form 
    $name     = $_POST['name'];
    $email    = $_POST['email'];
    $password = $_POST['password'];
    $user_department = $_POST['user_department'];
    


    $query = "INSERT INTO user(username ,u_email ,user_pass,user_dep)
	         values('$name','$email','$password','$user_department')";
    mysqli_query($conn, $query);
    $name       = "";
    $email      = "";
    $password   = "";
    $user_department ="";

    
}
include('include/h.php');  ?>

<div class="main-content">
    <div class="section_content section_content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">Manage User</div>
                        <div class="card-body">
                            <div class="card-title">
                                <h3 class="text-center title-2">Create User</h3>
                            </div>
                            <hr>
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">User name</label>
                                    <input name="name" type="text" class="form-control" value="<?php echo $name; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">User password</label>
                                    <input name="password" type="password" class="form-control" value="<?php echo $password; ?>">
                                </div>

                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">User email</label>
                                    <input name="email" type="email" class="form-control" value="<?php echo $email; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">User department</label>
                                    <input name="user_department" type="text" class="form-control" value="<?php echo $user_department; ?>">
                                </div>

                         
                                <div>
                                    <?php
                                    if ($update == true):
                                    ?>
                                        <button class="btn btn-info" type="submit" name="update"> Update</button>
                                    <?php else : ?>
                                        <button type="submit" class="btn btn-primary" name="submit">Save </button>
                                    <?php endif; ?>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row m-t-30">
                <div class="col-md-12">
                    <!-- DATA TABLE-->
                    <div class="table-responsive m-b-40">
                        <table class="table table-borderless table-data3">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>User department</th>
                                    <th>Edit</th>
                                    <th>Delete</th>


                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $query  = "select * from user";
                                $result = mysqli_query($conn, $query);
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td>{$row['user_id']}</td>";
                                    echo "<td>{$row['username']}</td>";
                                    echo "<td>{$row['u_email']}</td>";
                                    echo "<td>{$row['user_dep']}</td>";
                                    echo "<td><a href='user.php?id={$row['user_id']}&action=edit' class='btn btn-warning'>Edit</a></td>";
                                    echo "<td><a href='del.php?id={$row['user_id']}&type=user' class='btn btn-danger'>Delete</a></td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>

