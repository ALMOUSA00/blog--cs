<?php
$conn = mysqli_connect("localhost","root","","database");
if(!$conn){
    die("cannot connect ot server");
}

// $title       = "";
$mytextarea = "";
$name        = "";
$description = "";
$img         = "";
$res = "" ;
$update = false;

if (isset($_GET['action']) && $_GET['action'] == 'edit') {

    // fetch old data 
    $query  = "select * from post where p_id = {$_GET['id']}";
    $result = mysqli_query($conn, $query);
    $row    = mysqli_fetch_assoc($result);
   
    $name        = $row['post_name'];
    $description = $row['post_des'];
    $img       = $row['post_img'];
    $update = true;

}



?>

<!DOCTYPE html>
<html>
<head>
<title>Orange</title>

<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="plugins/revolution/css/settings.css" rel="stylesheet" type="text/css">
<link href="plugins/revolution/css/layers.css" rel="stylesheet" type="text/css">
<link href="plugins/revolution/css/navigation.css" rel="stylesheet" type="text/css">
<link href="css/style.css" rel="stylesheet">
<link href="layout/style/layout.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<link href="ss/teamm.css" rel="stylesheet" >

    <title>Orange</title>
<script>
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more";
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less";
    moreText.style.display = "inline";
  }
}
  </script>

</head>
<?php
$conn = mysqli_connect("localhost","root","","database");
if(!$conn){
    die("cannot connect ot server");
}

// $title       = "";
$mytextarea = "";
$name        = "";
$description = "";
$img         = "";
$res = "" ;
$update = false;

if (isset($_GET['action']) && $_GET['action'] == 'edit') {

    // fetch old data 
    $query  = "select * from post where p_id = {$_GET['id']} ";
    $result = mysqli_query($conn, $query);
    $row    = mysqli_fetch_assoc($result);
   
    $name        = $row['post_name'];
    $description = $row['post_des'];
    $img       = $row['post_img'];
    $update = true;

}



?>
<?php include 'include/header.php'?>

<!DOCTYPE html>
<html>
<head>
<title>Orange</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body>


<!-- RECENT POST CODE -->
<section class="recipes-section-two" style="background-image: url();">
  
<div class="p-5"> 
        <div class="sec-title text-center">
            <div class="divider"><img src="images/icons/divider_3.png" alt=""></div>
            <h2 id="r">Recent Posts</h2>
        </div>

        <div class="row" >
            <!-- Recipe Block Two -->

            <?php




            $query  = "select * from post  order by p_id desc ";
            $result = mysqli_query($conn, $query);
            $count = 0 ; 
            while ($row = mysqli_fetch_assoc($result)) {
              if($count < 4){
                echo '<div class="recipe-block-two col-lg-3 col-md-6 col-sm-12">
                <div class="image-box"> <figure class="image"><a href="post.php?id=' . $row['p_id'] . '&type=' . $row['post_name'] . '">
                <img src="ADMIN/images/' . $row['post_img'] . '" alt="" style="height:15rem; width:15rem;"></a></figure>';
                echo ' <div class="caption-box"> ';
                echo ' <h3 class="recipe-title text-capitalize">
                <a href="post.php?id=' . $row['p_id'] . '" "  >' .$row['post_name'] .' </a>
                        </h3>';
                echo ' <h4 class="recipe-title ">
                <p  class="text-dark text-truncate text-decoration-none text-capitalize " ' .$row['p_id'] . '&type=' .$row['post_des'] . ' </p>
                </h4>';
                echo ' <h4 class="recipe-title text-capitalize" >
                        <a href="post.php?id=' . $row['p_id'] . '" "  >More...</a>
                        </h4>';
                echo ' </div></div></div> ';
                
            }
             $count++;
          }
            ?>

        </div>
  </div>
</section>
<!--################################################################################################################################################-->
<div class="wrapper bgded overlay" style="background-image:url('images/g.png');">
  <article class="hoc container clear cta"> 
  
    <div class="three_quarter first">
      <h1 class="nospace">Vision</h1>
      <p class="nospace">Orange seeks to be the responsible digital leader in Jordan</p>
    </div>
    <footer class="one_quarter" style="float:right; padding-top:25px;"><a class="btn center" href="https://www.orange.jo/en/pages/about-orange.aspx">Read More &raquo;</a></footer>
   
  </article>
</div>

<section class="recipes-section-two" style="background-image: url();">
  <div class="auto-container">
     <div class="p-5">
        <div class="sec-title text-center">
          
            <h2>Posts</h2>
        </div>

        <div class="row">
        

            <?php

function fun($description, $limit_lines){
  $count = 0;
  foreach(explode("\n", $description) as $line){
      $count++;
      echo $line."\n";
      if ($count == $limit_lines) break;      
      
  }
} 
            $query  = "select * from post ";
            $result = mysqli_query($conn, $query);
            $string =substr('post_des', 0, 5) ;
            $words = explode(" ", $string);
            $first = join(" ", array_slice($words, 0, 5));
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="recipe-block-two col-lg-3 col-md-6 col-sm-12">
                <div class="image-box"> <figure class="image"><a href="post.php?id=' . $row['p_id'] . '&type=' . $row['post_name'] . '">
                <img src="ADMIN/images/' . $row['post_img'] . '" alt="" style="height:15rem; width:15rem;"></a></figure>';
                echo ' <div class="caption-box"> ';
                echo ' <h3 class="recipe-title text-capitalize">
                <a href="post.php?id=' . $row['p_id'] . '" "  >' .$row['post_name'] .' </a>
                        </h3>';
                echo ' <h4 class="recipe-title ">
                <p  class="text-dark text-truncate text-decoration-none text-capitalize " ' .$row['p_id'] . '&type=' .$row['post_des'] . ' </p>
                </h4>';
                echo ' <h4 class="recipe-title text-capitalize" >
                        <a href="post.php?id=' . $row['p_id'] . '" "  >More...</a>
                        </h4>';
                echo ' </div></div></div> ';
                
            }
            ?>

        </div>
    </div>
</article>
</section>
<!--########################################################################################################################################################33-->
<div class="wrapper bgded overlay" style="background-image:url('images/m.png');">
  <article class="hoc container clear cta"> 
    
    <div class="three_quarter first">
      <h1 class="nospace">Our Mission:</h1>
      <p class="nospace">To Offer the best network, innovative digital solutions with unmatched customer experience by empowered orange teams.</p>
    </div>
    <footer class="one_quarter"  style="float:right; padding-top:35px;"><a class="btn center" href="https://www.orange.jo/en/pages/about-orange.aspx">Read More &raquo;</a></footer>
   
  </article>
</div>
<!-- ################################################################################################ -->

<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<section id="team" class="pb-5">
    <div class="container">
        <h5 class="section-title">OUR TEAM</h5>
        <div class="row">

            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                    <div class="mainflip">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="IMG/1.png" alt="card image"></p>
                                    <h4 class="card-title"> Thierry Marigny</h4>
                                    <p class="card-text">Chief Exceutive Officer</p>
                                    <p class="card-text">Unit: GCEO</p>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                    <h4 class="card-title">Thierry Marigny</h4>
                                    <p class="card-text">Chief Exceutive Officer  </p>
                                    <ul class="list-inline">
                                        <li class="list-inline-item"> 
                                        </li>
                                         
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                    <div class="mainflip">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="IMG/2.png" alt="card image"></p>
                                    <h4 class="card-title">Ibrahim Harb Nasser</h4>
                                    <p class="card-text"> Chief Legal, Regularoty , Sourcing and Supply Chain & Human Resources Officer  </p>
                                    <p class="card-text"> Units: Legal, Regularoty , Sourcing and Supply Chain and  Human Resources Officer  </p>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                    <h4 class="card-title">Ibrahim Harb Nasser</h4>
                                    <p class="card-text">Chief Legal, Regularoty ,Sourcing and Supply Chain & Human Resources Officer </p>
                                    <p class="card-text"> Human Resources Officer </p>
                                    <ul class="list-inline">
                                        <li class="list-inline-item"> 
                                        </li>
                                         
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                    <div class="mainflip">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="IMG/3.png" alt="card image"></p>
                                    <h4 class="card-title">Raslan Deiranieh</h4>
                                    <p class="card-text"> Deputy Group CEO-Cheif Finance & Strategy Officer</p>
                                    <p class="card-text">Units:  Finance Corporate Services </p>
                                    <p class="card-text"> Network Information Security</p>
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                    <h4 class="card-title">Raslan Deiranieh</h4>
                                    <p class="card-text">Units:  Finance Corporate Services </p>
                                    <p class="card-text"> Network Information Security</p>
                                    <ul class="list-inline">
                                        <li class="list-inline-item"> 
                                        </li>
                                         
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                    <div class="mainflip">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="IMG/4.png" alt="card image"></p>
                                    <h4 class="card-title">Naila Al Dawoud </h4>
                                    <p class="card-text">Cheif Consumer Market Officer </p>
                                    <p class="card-text">Units: Consumer Market Business </p>
                                     
                                
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                    <h4 class="card-title">Naila Al Dawoud</h4>
                                    <p class="card-text">Cheif Consumer Market Officer</p>
                                    <p class="card-text">Unit: Consumer Market Business</p>
                                    <ul class="list-inline">
                                        <li class="list-inline-item"> 
                                        </li>
                                         
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                    <div class="mainflip">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="IMG/5.png" alt="card image"></p>
                                    <h4 class="card-title">Samer Haj</h4>
                                    <p class="card-text">Chief Consumer Sales Officer </p>
                                    <p class="card-text">Unit: Consumer Sales Business Unit </p>
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                    <h4 class="card-title">Samer Haj</h4>
                                    <p class="card-text">Chief Consumer Sales Officer </p>
                                    <p class="card-text">Unit: Consumer Sales Business Unit </p>
                                    <ul class="list-inline">
                                        <li class="list-inline-item"> 
                                        </li>  
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" >
                    <div class="mainflip flip-0">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="IMG/6.png" alt="card image"></p>
                                    <h4 class="card-title">Waleed Al Doulat </h4>
                                    <p class="card-text">Chief ITN and Wholesale Officer</p>
                                    <p class="card-text">Units: Information Technology & Network</p>
                                    <p class="card-text">Wholesale Business</p>
                                     
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                <h4 class="card-title">Waleed Al Doulat </h4>
                                    <p class="card-text">Chief ITN and Wholesale Officer</p>
                                    <p class="card-text">Units: Information Technology & Network</p>
                                    <p class="card-text">Wholesale Business</p>
                                    <ul class="list-inline">
                                        <li class="list-inline-item"> 
                                        </li>
                                         
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" >
                    <div class="mainflip flip-0">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="IMG/7.png" alt="card image"></p>
                                    <h4 class="card-title">Sami Smeirat</h4>
                                    <p class="card-text"> Enterprise BU CEO-Orange VP</p>
                                    <p class="card-text"> Unit: Enterprise Business Unit</p> 
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                <h4 class="card-title">Sami Smeirat</h4>
                                    <p class="card-text"> Enterprise BU CEO-Orange VP</p>
                                    <p class="card-text"> Unit: Enterprise Business Unit</p> 
                                    <ul class="list-inline">
                                        <li class="list-inline-item"> 
                                        </li> 
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" >
                    <div class="mainflip flip-0">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src=" IMG/8.png" alt="card image"></p>
                                    <h4 class="card-title">Wilfried Yver</h4>
                                    <p class="card-text"> Digital Data , Innovation & Money Officer</p>
                                    <p class="card-text"> Unit: Digital, Data, Innovation & Money  </p> 
                                     
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                <h4 class="card-title">Wilfried Yver</h4>
                                    <p class="card-text"> Digital Data , Innovation & Money Officer</p>
                                    <p class="card-text"> Unit: Digital, Data, Innovation & Money  </p> 
                                    <ul class="list-inline">
                                        <li class="list-inline-item"> 
                                        </li> 
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
          

        </div>
    </div>
</section>

    <?php include 'include/footer.php'?>

    <script src="layout/scripts/jquery.min.js"></script>
    <script src="layout/scripts/jquery.backtotop.js"></script>
    <script src="layout/scripts/jquery.mobilemenu.js"></script>
    </body>
    </html>