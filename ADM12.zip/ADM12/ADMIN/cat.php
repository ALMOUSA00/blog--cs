<?php
require('include/connection.php');

$name        = "";
$description = "";
$update      = false;

if (isset($_GET['action']) && $_GET['action'] == 'edit') {

     
    $query  = "select * from category where cat_id = {$_GET['id']}";
    $result = mysqli_query($conn, $query);
    $row    = mysqli_fetch_assoc($result);
    $name        = $row['cat_name'];
    $description = $row['cat_des'];
    $update = true;
   


    if (isset($_POST['update'])) {
 
        $name        = $_POST['name'];
        $description = $_POST['description'];



        $query = "UPDATE category SET cat_name = '$name',
	                                  cat_des = '$description'
	                            WHERE cat_id = {$_GET['id']}";
        mysqli_query($conn, $query);

        $update = false;
        header("location:cat.php");
    }
}

if (isset($_POST['submit'])) {
    // fetch data from form 
    $name        = $_POST['name'];
    $description = $_POST['description'];
   


    $query = "INSERT INTO category(cat_name ,cat_des)
	         values('$name','$description')";
    mysqli_query($conn, $query);
    $name        = "";
    $description = "";
   

    
}


include('include/h.php');  ?>

<div class="main-content">
    <div class="section_content section_content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">Manage category</div>
                        <div class="card-body">
                            <div class="card-title">
                                <h3 class="text-center title-2">Create category</h3>
                            </div>
                            <hr>
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">category name</label>
                                    <input name="name" type="text" class="form-control" value="<?php echo $name; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">category description</label>
                                    <input name="description" type="text" class="form-control" value="<?php echo $description; ?>">
                                </div>
                               

                                <div>
                                    <?php
                                    if ($update == true) :
                                    ?>
                                        <button class="btn btn-info" type="submit" name="update"> Update</button>
                                    <?php else : ?>
                                        <button type="submit" class="btn btn-primary" name="submit">Save </button>
                                    <?php endif; ?>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row m-t-30">
                <div class="col-md-12">
                    <!-- DATA TABLE-->
                    <div class="table-responsive m-b-40">
                        <table class="table table-borderless table-data3">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>description</th>
                                    <th>Edit</th>
                                    <th>Delete</th>


                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query  = "select * from category";
                                $result = mysqli_query($conn, $query);
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td>{$row['cat_id']}</td>";
                                    echo "<td>{$row['cat_name']}</td>";
                                    echo "<td>{$row['cat_des']}</td>";
                                    echo "<td><a href='cat.php?id={$row['cat_id']}&action=edit' class='btn btn-warning'>Edit</a></td>";
                                    echo "<td><a href='del.php?id={$row['cat_id']}&type=cat' class='btn btn-danger'>Delete</a></td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>