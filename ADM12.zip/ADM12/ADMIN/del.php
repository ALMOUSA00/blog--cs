<?php
require('include/connection.php');

if ($_GET['type'] == 'admin') {
    $query = "delete from ad where admin_id  = {$_GET['id']}";
    mysqli_query($conn, $query);

    header("location:admin.php");
}
if ($_GET['type'] == 'cat') {
    $query = "delete from category where cat_id  = {$_GET['id']}";
    mysqli_query($conn, $query);

    header("location:cat.php");
}

if ($_GET['type'] == 'pro') {
    $query = "delete from products where pro_id  = {$_GET['id']}";
    mysqli_query($conn, $query);
    // header("location:Manage_products.php");
}

if ($_GET['type'] == 'post') {
    $query = "delete from post where p_id  = {$_GET['id']}";
    mysqli_query($conn, $query);

    header("location:post.php");
}

if ($_GET['type'] == 'user') {
    $query = "delete from user where user_id  = {$_GET['id']}";
    mysqli_query($conn, $query);

    header("location:user.php");
}