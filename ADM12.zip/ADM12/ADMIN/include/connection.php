<?php
$conn = mysqli_connect("localhost","root","","database");
    if(!$conn){
        die("cannot connect ot server");
    }

