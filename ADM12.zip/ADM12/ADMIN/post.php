<?php
require('include/connection.php');

// $title       = "";
$mytextarea = "";
$name        = "";
$description = "";
$img         = "";
$cat_id      ="";
$update = false;

if (isset($_GET['action']) && $_GET['action'] == 'edit') {

    // fetch old data 
    $query  = "select * from post where p_id = {$_GET['id']}";
    $result = mysqli_query($conn, $query);
    $row    = mysqli_fetch_assoc($result);
   
    $name        = $row['post_name'];
    $description = $row['post_des'];
    $img       = $row['post_img'];
    $update = true;
    // print_r($row);
    $query ="select cat_id from post where p_id = {$_GET['id']}";
    $selected_category = mysqli_query($conn,$query);
    $fetched_data = mysqli_fetch_all($selected_category);


    if (isset($_POST['update'])) {

        // fetch data from form 
        $name        = $_POST['name'];
        $description = $_POST['description'];
        $img =$_POST['img'];
        $cat_id = $_POST['cat_id'];

        if ($_FILES["img"]["name"]) {
            $filename = $_FILES["img"]["name"];
            $tempname = $_FILES["img"]["tmp_name"];
            $folder = "images/" . $filename;

            if (move_uploaded_file($tempname, $folder)) {
                $msg = "Image uploaded successfully";
            } else {
                $msg = "Failed to upload image";
            }
        } else {
            $filename =  $row['post_img'];
        };

        $query = "UPDATE post SET 
	                           post_name = '$name',
                               post_des = '$description',
	                           post_img = '$filename',
                               cat_id   =  '$cat_id[0]'
	                           WHERE p_id = {$_GET['id']}";
        mysqli_query($conn, $query);

        $update = false;
        header("location:post.php");
    }
}

if (isset($_POST['submit'])) {
    // fetch data from form 
    $name        = $_POST['name'];
    $description = $_POST['description'];
    $cat_id      =$_POST['cat_id'];
    $filename = $_FILES["img"]["name"];
    $tempname = $_FILES["img"]["tmp_name"];
    $folder = "images/" . $filename;


    $query = "INSERT INTO post(post_name ,post_des ,post_img, cat_id)
	         values('$name','$description','$filename','$cat_id[0]')";
    mysqli_query($conn, $query);
    // $title       ="";
    $name        = "";
    $description = "";
    $filename    = "";
    $cat_id      = "";

    if (move_uploaded_file($tempname, $folder)) {
        $msg = "Image uploaded successfully";
    } else {
        $msg = "Failed to upload image";
    }
}


include('include/h.php');  ?>

<div class="main-content">
    <div class="section_content section_content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">Manage Post</div>
                        <div class="card-body">
                            <div class="card-title">
                                <h3 class="text-center title-2">Create Post</h3>
                            </div>
                            <hr>
                            <form action="" method="post" enctype="multipart/form-data">
                            <!-- <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">Title</label>
                                    <input name="title" type="text" class="form-control" value="<?//php echo $title; ?>">
                                </div> -->
                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">Title</label>
                                    <input name="name" type="text" class="form-control" value="<?php echo $name; ?>">
                                </div>

                               
                                  
    <!-- <div method="post">
        <textarea id="mytextarea" placeholder="Description"></textarea>
        <input id="description" name="description" type="text" class="form-control" value="<?php //echo $description; ?>">
</div> -->



                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">Description</label>
                                    <input name="description" type="text" class="form-control" value="<?php echo $description; ?>">
                                </div> 
                                <div class="row form-group ">
                                    <div class="col col-md-3">
                                        <label for="cat_id" class=" form-control-label">Select category</label>
                                    </div>
                                    <div class="col col-md-9">
                                        <select name="cat_id[]" class="form-control col-lg-6">
                                            <?php
                                            $query  = "select * from category";
                                            $result = mysqli_query($conn, $query);

                                            if ($update != true) {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    echo "<option value='{$row['cat_id']}'>{$row['cat_name']}</option>";
                                                }
                                            } else {
                                                // to fetch the selected categories
                                                $row = mysqli_fetch_all($result);
                                                foreach ($row as $k => $value) {

                                                    foreach ($fetched_data as $key => $value2) {
                                                        if ($row[$k][0] == $value2[0]) {
                                                            echo "<option selected value='{$value[0]}'>{$value[1]}</option>";
                                                            unset($row[$k]);
                                                            continue 2;
                                                        }
                                                    }
                                                    echo "<option  value='{$value[0]}'>{$value[1]}</option>";
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">Image</label>
                                    <input name="img" type="file" accept="image/*" class="form-control">
                                    <?php
                                    if ($update == true) {
                                        echo  " <p>current image : </p> <img  height='100px' width='100px' src='images/{$img}' alt='test'>";
                                    } ?>

                                    
                                


                                <div class="form-group"> 
                                    <label for="cc-payment" class="control-label mb-1" style="padding-left:20px;">
                                        <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked/>
                                      <label class="form-check-label" for="flexCheckChecked">
                                            Published
                                      </label>
                                        </div> 



                                </div>



                                <div>
                                    <?php
                                    if ($update == true) :
                                    ?>
                                        <button class="btn btn-info" type="submit" name="update"> Update</button>
                                    <?php else : ?>
                                        <button type="submit" class="btn btn-primary" name="submit">Save </button>
                                    <?php endif; ?>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row m-t-30">
                <div class="col-md-12">
                    <!-- DATA TABLE-->
                    <div class="table-responsive m-b-40">
                        <table class="table table-borderless table-data3">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <!-- <th>title</th> -->
                                    <th>Name</th>
                                    <th>description</th>
                                    <th>Category</th>
                                    <th>image</th>
                                    <th>Edit</th>
                                    <th>Delete</th>


                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query  = "select * from post";
                                $result = mysqli_query($conn, $query);
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td>{$row['p_id']}</td>";
                                    // echo "<td>{$row['post_title']}</td>";
                                    echo "<td>{$row['post_name']}</td>";
                                    echo "<td>{$row['post_des']}</td>";
                                    echo "<td>";
                                    $cat_name_query  = "select * from category where cat_id = {$row['cat_id']} ";
                                    $cat_name_result = mysqli_query($conn, $cat_name_query);
                                    $cat_name_row = mysqli_fetch_assoc($cat_name_result);
                                    echo "{$cat_name_row['cat_name']}</td>";
                                    echo "<td><img  height='100px' width='100px' src='images/{$row['post_img']}' alt='test'></td>";
                                    echo "<td><a href='post.php?id={$row['p_id']}&action=edit' class='btn btn-warning'>Edit</a></td>";
                                    echo "<td><a href='del.php?id={$row['p_id']}&type=post' class='btn btn-danger'>Delete</a></td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- END DATA TABLE-->
                </div>
            </div>
        </div>
    </div>
</div>


<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <script type="text/javascript">
        tinymce.init({
            selector: '#mytextarea'
        });
    </script>