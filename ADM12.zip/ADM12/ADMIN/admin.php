<?php

require('include/connection.php');

$name     = "";
$email    = "";
$password = "";
$update  = false;

if (isset($_GET['action']) && $_GET['action'] == 'edit') {

    // fetch old data 
    $query  = "select * from ad where admin_id = {$_GET['id']}";
    $result = mysqli_query($conn, $query);
    $row    = mysqli_fetch_assoc($result);
    $name   = $row['ad_name'];
    $email  = $row['a_email'];
    $password      = $row['a_pass'];
    $update = true;
    // print_r($row);


    if (isset($_POST['update'])) {

        // fetch data from form 
        $name     = $_POST['name'];
        $email    = $_POST['email'];
        $password = $_POST['password'];

     

        $query = "UPDATE ad SET ad_name = '$name',
	                           a_email = '$email',
	                           a_pass = '$password'
	                           WHERE admin_id = {$_GET['id']}";
        mysqli_query($conn, $query);

        $update = false;
        header("location:admin.php");
    }
}

if (isset($_POST['submit'])) {
    // fetch data from form 
    $name     = $_POST['name'];
    $email    = $_POST['email'];
    $password = $_POST['password'];
    


    $query = "INSERT INTO ad(ad_name ,a_email ,a_pass)
	         values('$name','$email','$password')";
    mysqli_query($conn, $query);
    $name       = "";
    $email      = "";
    $password   = "";

    
}
include('include/h.php');  ?>

<div class="main-content">
    <div class="section_content section_content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">Manage Admin</div>
                        <div class="card-body">
                            <div class="card-title">
                                <h3 class="text-center title-2">Create Admin</h3>
                            </div>
                            <hr>
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">Admin name</label>
                                    <input name="name" type="text" class="form-control" value="<?php echo $name; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">Admin password</label>
                                    <input name="password" type="password" class="form-control" value="<?php echo $password; ?>">
                                </div>

                                <div class="form-group">
                                    <label for="cc-payment" class="control-label mb-1">Admin email</label>
                                    <input name="email" type="email" class="form-control" value="<?php echo $email; ?>">
                                </div>

                         
                                <div>
                                    <?php
                                    if ($update == true) :
                                    ?>
                                        <button class="btn btn-info" type="submit" name="update"> Update</button>
                                    <?php else : ?>
                                        <button type="submit" class="btn btn-primary" name="submit">Save </button>
                                    <?php endif; ?>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row m-t-30">
                <div class="col-md-12">
                    <!-- DATA TABLE-->
                    <div class="table-responsive m-b-40">
                        <table class="table table-borderless table-data3">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    
                                    <th>email</th>
                                    
                                    <th>Edit</th>
                                    <th>Delete</th>


                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $query  = "select * from ad";
                                $result = mysqli_query($conn, $query);
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td>{$row['admin_id']}</td>";
                                    echo "<td>{$row['ad_name']}</td>";
                                    echo "<td>{$row['a_email']}</td>";
                                    echo "<td><a href='admin.php?id={$row['admin_id']}&action=edit' class='btn btn-warning'>Edit</a></td>";
                                    echo "<td><a href='del.php?id={$row['admin_id']}&type=admin' class='btn btn-danger'>Delete</a></td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>

