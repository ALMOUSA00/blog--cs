<?php
$conn = mysqli_connect("localhost","root","","database");
if(!$conn){
    die("cannot connect ot server");
}

// $title       = "";
$mytextarea = "";
$name        = "";
$description = "";
$img         = "";
$date ="";
$res = "" ;
$update = false;

if (isset($_GET['action']) && $_GET['action'] == 'edit') {

    // fetch old data 
    $query  = "select * from post where p_id = {$_GET['id']}";
    $result = mysqli_query($conn, $query);
    $row    = mysqli_fetch_assoc($result);
   
    $name        = $row['post_name'];
    $description = $row['post_des'];
    $img       = $row['post_img'];
    $date = $row['post_date']; 

    $update = true;

}



?>

<?php include'include/header.php'?>
<br><br><br>

<!DOCTYPE html>
<html>
<head>
<title>Orange</title>
<style>
  .p1 {
  font-family: "Times New Roman", Times, serif;
}

.truncate-line-clamp {
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical; 
  width: 250px;
  font-size: 20px;
  text-transform: capitalize;
  overflow: hidden;
  
}

  </style>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">

<div class="wrapper row3">
  <main class="hoc container clear"> 
  
<!-- ################################################################################################ -->
    <h2 style="color:darkblue;">Post</h2>
    
<?php
$query  = "select * from post";
 $result = mysqli_query($conn, $query);
                               
                        
                                ?>


<div class="row clearfix">
  

                                <!-- Shop Item -->
                                <?php
                                $count = 0;
                        if (isset($_GET['id'])) {
                            $sql  = "select post_name , p_id from post where p_id= {$_GET['id']}";
                            $store = mysqli_fetch_assoc(mysqli_query($conn, $sql));
                            $storeId = $store['p_id'];
                      
                                $result = mysqli_query($conn, $query);
                                while ($row = mysqli_fetch_assoc($result)) {
                                  //hoon bs sawe el database w jrb lw bzbot // 
                                  if($_GET['id']){
                                    if($_GET['id'] == $row['p_id']){ 
                                      //to print only one post 

                                  echo "<div class='shop-item col-lg-4 col-md-6 col-sm-12'>
  
                                  <ul class='nospace group '>
                                  <li class='one_quarter first'>
  
                                  <div class='col-md-12 ' style='width:200%;'>
                                  <div class='postexcerpt' >
                                  
                                                              <figure class='image'>
                                                              <img src='images/post/{$row['post_img']}' alt=''  style='height: 17rem'></figure>
                                                              <h3 class='name'>{$row['post_name']}</h3>
                                                              <div class='sale-tag'> 
                                                              <p class='name'>{$row['post_des']}</p>
                                                              
                                                              </div>  
                                                              <br> <br>
                                                   
                                                             
                                                      </div>
                                                      </div>

                                                      
                                                      </li>
                                                      
                                                 
                                                      
                                                      </ul>

                                                    
                                                  </div>";
                                  }

                                  

                                
  
                                  $count++;
                                
                 
                          }
                        } 
                      }
                          
                        ?>
  </div>
                    </div>
                    </main>

                    <div class="wrapper bgded overlay" style="background-image:url('images/m.png');">
  <article class="hoc container clear cta"> 
    
    <div class="three_quarter first">
      <h1 class="nospace">Our Mission:</h1>
      <p class="nospace">To Offer the best network, innovative digital solutions with unmatched customer experience by empowered orange teams.</p>
    </div>
    <footer class="one_quarter"  style="float:right; padding-top:35px;"><a class="btn center" href="https://www.orange.jo/en/pages/about-orange.aspx">Read More &raquo;</a></footer>
   
  </article>
</div>

<div class="wrapper row3">
   <main class="hoc container clear">
        <div class="row" >
            <!-- Recipe Block Two -->

            <h1 style="color:black;"> More news.. </h1>
            <?php

            $query  = "select * from post  order by p_id desc ";
            $result = mysqli_query($conn, $query);
            $count = 0 ; 
            while ($row = mysqli_fetch_assoc($result)) {
              if($count < 4){
                echo '<div class="recipe-block-two col-lg-3 col-md-6 col-sm-12  ">
                <div class="image-box one_half first"> <br> <br>
                 <img src="images/post/' . $row['post_img'] . '" alt="" style="height:15rem;"></a></div>';
                   
            echo '<div class="one_half  text-capitalize text-truncate " >';
            echo ' <br><br><br> ';
            echo '<div class="caption-box  pl-20  color-black  sale-tag ">
            <h3 class="recipe-title text-capitalize">
            ' .$row['post_name'] .' 
            </h3>';
            echo ' <h4 class="truncate-line-clamp " ' .$row['p_id'] . '"  ">' .$row['post_des'] .  '  </h4>
                            </h4>';
            
                           echo ' <h4 class="recipe-title " >
                           <a href="post.php?id=' . $row['p_id'] . ' " > <span id="more">More...</span></a>
                           </h4>';
                   echo ' </div></div></div> ';
                
            }
             $count++;
          }
            ?>
          </div>  
        </main>
    </div>   

    <!-- JAVASCRIPTS -->
    <script src="layout/scripts/jquery.min.js"></script>
    <script src="layout/scripts/jquery.backtotop.js"></script>
    <script src="layout/scripts/jquery.mobilemenu.js"></script>
    <script src="ckeditor/ckeditor.js" ></script>
    <script src="//cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <script type="text/javascript">
        tinymce.init({
            selector: '#mytextarea'
        });
    </script>
    </body>
    </html>